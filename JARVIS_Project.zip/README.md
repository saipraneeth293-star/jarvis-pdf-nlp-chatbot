# 🤖 JARVIS — Conversational PDF NLP Chatbot

JARVIS is a Python and NLP based conversational chatbot that can upload and analyze text-based PDF documents, answer questions using TF-IDF retrieval, summarize documents, maintain short conversation context, and show source pages.

## Features

- PDF upload through Streamlit
- Page-by-page PDF text extraction
- Text cleaning and chunking
- TF-IDF vectorization
- Cosine-similarity document retrieval
- Question answering from the uploaded PDF
- Extractive PDF summarization
- Short conversational memory for follow-up questions
- Source page references
- Clean Streamlit interface

## Technology

- Python
- Streamlit
- PyPDF
- scikit-learn
- TF-IDF
- Cosine Similarity

## Run locally

```bash
python -m venv venv
```

Windows PowerShell:

```powershell
.\venv\Scripts\Activate.ps1
```

Install dependencies:

```powershell
pip install -r requirements.txt
```

Run:

```powershell
python -m streamlit run app.py
```

Open the displayed local URL, normally:

```text
http://localhost:8501
```

## Usage

1. Open JARVIS.
2. Upload a text-based PDF.
3. Ask a question about the document.
4. Ask follow-up questions.
5. Ask `Summarize this PDF` for an extractive summary.
6. Answers include source page numbers when available.

## Limitations

This project is designed as an NLP retrieval chatbot rather than a generative LLM. It works best with text-based PDFs. Scanned/image-only PDFs require OCR, which is not included in this lightweight version.

## Project structure

```text
JARVIS/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── sample_pdfs/
```
