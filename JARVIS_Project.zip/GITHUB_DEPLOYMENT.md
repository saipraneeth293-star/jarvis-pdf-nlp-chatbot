# GitHub Deployment Guide

## 1. Create the project folder

Keep these files:

```text
JARVIS/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── sample_pdfs/
```

Do NOT upload:

```text
venv/
__pycache__/
```

## 2. Test locally

Activate your environment:

```powershell
.\venv\Scripts\Activate.ps1
```

Install:

```powershell
pip install -r requirements.txt
```

Run:

```powershell
python -m streamlit run app.py
```

## 3. Create a GitHub repository

On GitHub, create a new repository named:

```text
jarvis-pdf-nlp-chatbot
```

A public repository is convenient for an academic project.

## 4. Initialize Git

From the JARVIS folder:

```powershell
git init
git add .
git commit -m "Initial JARVIS chatbot project"
```

Rename the branch:

```powershell
git branch -M main
```

Then add your GitHub repository as the remote:

```powershell
git remote add origin YOUR_GITHUB_REPOSITORY_URL
```

Push:

```powershell
git push -u origin main
```

## 5. Deploy

For a Streamlit-hosted deployment, connect the GitHub repository, select:

```text
app.py
```

as the main application file, and deploy. The platform installs packages from `requirements.txt`.

## 6. Important

Do not upload your `venv` folder. GitHub should contain the source code and dependency file, not the local Python environment.

If the PDF contains private information, do not commit it to a public repository.
