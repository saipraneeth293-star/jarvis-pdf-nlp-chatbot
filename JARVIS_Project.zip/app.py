import re
from pathlib import Path

import streamlit as st
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# -------------------- Page configuration --------------------
st.set_page_config(
    page_title="JARVIS AI Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -------------------- Session state --------------------
defaults = {
    "messages": [],
    "pdf_name": "",
    "pdf_text": "",
    "chunks": [],
    "chunk_pages": [],
    "vectorizer": None,
    "matrix": None,
    "page_count": 0,
}

for key, value in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = value


# -------------------- Utilities --------------------
def clean_text(text):
    return re.sub(r"\s+", " ", text or "").strip()


def split_sentences(text):
    return [
        s.strip()
        for s in re.split(r"(?<=[.!?])\s+", clean_text(text))
        if len(s.strip()) > 20
    ]


def extract_pdf(uploaded_file):
    """Extract text page-by-page so source pages are retained."""
    try:
        reader = PdfReader(uploaded_file)
        pages = []

        for page_number, page in enumerate(reader.pages, start=1):
            try:
                text = clean_text(page.extract_text() or "")
            except Exception:
                text = ""
            pages.append(text)

        full_text = "\n\n".join(
            f"[Page {i}] {text}"
            for i, text in enumerate(pages, start=1)
            if text
        )

        return full_text, pages, len(reader.pages)
    except Exception as exc:
        st.error(f"Could not load PDF: {exc}")
        return "", [], 0


def create_chunks_from_pages(pages, chunk_size=1200, overlap=200):
    chunks = []
    chunk_pages = []

    for page_number, page_text in enumerate(pages, start=1):
        text = clean_text(page_text)
        if not text:
            continue

        start = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))
            chunk = text[start:end].strip()

            if chunk:
                chunks.append(chunk)
                chunk_pages.append(page_number)

            if end >= len(text):
                break

            start = max(0, end - overlap)

    return chunks, chunk_pages


def build_search_engine(chunks):
    if not chunks:
        return None, None

    try:
        vectorizer = TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            max_features=15000,
        )
        matrix = vectorizer.fit_transform(chunks)
        return vectorizer, matrix
    except Exception as exc:
        st.error(f"Could not build the NLP search engine: {exc}")
        return None, None


def search_document(question, top_k=5):
    if (
        not st.session_state.chunks
        or st.session_state.vectorizer is None
        or st.session_state.matrix is None
    ):
        return []

    try:
        query_vector = st.session_state.vectorizer.transform([question])
        scores = cosine_similarity(
            query_vector, st.session_state.matrix
        )[0]

        ranked = scores.argsort()[::-1]
        results = []

        for idx in ranked[:top_k]:
            score = float(scores[idx])
            if score > 0:
                results.append(
                    {
                        "text": st.session_state.chunks[idx],
                        "page": st.session_state.chunk_pages[idx],
                        "score": score,
                    }
                )

        return results
    except Exception:
        return []


# -------------------- Summarization --------------------
def summarize_document(text, sentence_count=7):
    sentences = split_sentences(text)

    if not sentences:
        return "I could not find enough readable text to summarize."

    if len(sentences) <= sentence_count:
        return " ".join(sentences)

    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
        )
        matrix = vectorizer.fit_transform(sentences)
        word_scores = matrix.sum(axis=0).A1
        sentence_scores = (matrix @ word_scores).A1

        ranked = sorted(
            range(len(sentences)),
            key=lambda i: sentence_scores[i],
            reverse=True,
        )

        selected = sorted(ranked[:sentence_count])
        return " ".join(sentences[i] for i in selected)
    except Exception:
        return " ".join(sentences[:sentence_count])


# -------------------- Conversation handling --------------------
def normal_conversation(question):
    q = question.lower().strip()

    if q in {"hello", "hi", "hey", "hello jarvis", "hi jarvis", "hey jarvis"}:
        return "Hello! I'm JARVIS. 🤖 Upload a PDF and ask me anything about it."

    if "who are you" in q or "what are you" in q:
        return (
            "I'm JARVIS, a Python NLP chatbot with PDF document intelligence. "
            "I can search documents, answer questions, summarize PDFs, "
            "and keep short conversational context."
        )

    if "what can you do" in q or "what do you do" in q:
        return (
            "I can read a PDF, search its contents using TF-IDF, answer "
            "document questions, summarize the document, show source pages, "
            "and understand simple follow-up questions."
        )

    if q in {"thanks", "thank you", "thanks jarvis", "thank you jarvis"}:
        return "You're welcome! 🤖"

    return None


def is_summary_request(question):
    q = question.lower().strip()
    phrases = [
        "summarize", "summarise", "summary",
        "main points", "key points", "important points",
        "summarize this pdf", "summarise this pdf",
        "summarize the pdf", "summarise the pdf",
        "summarize this document", "summarise this document",
        "summarize the document", "summarise the document",
        "give me a summary", "give me the summary",
    ]
    return any(p in q for p in phrases)


def resolve_question(question):
    """Add the previous user topic for simple follow-up questions."""
    if not st.session_state.messages:
        return question.strip()

    q = question.strip().lower()
    followup_terms = {
        "it", "its", "they", "them", "their",
        "this", "that", "these", "those",
        "what about it", "tell me more",
        "explain more", "why", "how",
    }

    is_followup = any(term in q for term in followup_terms)
    if not is_followup:
        return question.strip()

    previous_questions = [
        m["content"]
        for m in st.session_state.messages
        if m["role"] == "user"
    ]

    if previous_questions:
        return f"{previous_questions[-1]}. Follow-up question: {question}"

    return question.strip()


def generate_pdf_answer(question, results):
    if not results:
        return (
            "I couldn't find relevant information in the uploaded PDF. "
            "Try asking the question with different wording."
        )

    question_words = set(
        re.findall(r"\b[a-zA-Z]{3,}\b", question.lower())
    )

    candidates = []

    for result in results:
        for sentence in split_sentences(result["text"]):
            sentence_words = set(
                re.findall(r"\b[a-zA-Z]{3,}\b", sentence.lower())
            )
            overlap = len(question_words & sentence_words)
            candidates.append(
                (overlap, result["score"], result["page"], sentence)
            )

    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)

    selected = []
    pages = []

    for _, _, page, sentence in candidates:
        if sentence not in selected:
            selected.append(sentence)
            pages.append(page)
        if len(selected) >= 5:
            break

    if not selected:
        return "I couldn't find a suitable answer in the uploaded document."

    answer = " ".join(selected)
    if len(answer) > 1800:
        answer = answer[:1800].rsplit(" ", 1)[0] + "..."

    unique_pages = sorted(set(pages))
    page_text = ", ".join(str(p) for p in unique_pages[:5])

    return f"### Answer\n{answer}\n\n📄 **Source page(s):** {page_text}"


def generate_answer(question):
    conversational = normal_conversation(question)
    if conversational:
        return conversational

    if not st.session_state.pdf_name:
        return "Please upload a PDF first. 📄 Then I can answer questions about it."

    if is_summary_request(question):
        summary = summarize_document(st.session_state.pdf_text)
        return f"### 📄 Document Summary\n{summary}"

    resolved = resolve_question(question)
    results = search_document(resolved, top_k=5)
    return generate_pdf_answer(resolved, results)


# -------------------- Sidebar --------------------
with st.sidebar:
    st.title("🤖 JARVIS")
    st.caption("Python NLP PDF Assistant")
    st.divider()

    st.subheader("📄 Upload PDF")
    uploaded_file = st.file_uploader(
        "Choose a PDF file",
        type=["pdf"],
        help="Upload a text-based PDF and ask JARVIS questions about it.",
    )

    if uploaded_file is not None:
        if st.session_state.pdf_name != uploaded_file.name:
            with st.spinner("JARVIS is reading your PDF..."):
                full_text, pages, page_count = extract_pdf(uploaded_file)

                if full_text:
                    chunks, chunk_pages = create_chunks_from_pages(pages)
                    vectorizer, matrix = build_search_engine(chunks)

                    if vectorizer is not None:
                        st.session_state.pdf_text = full_text
                        st.session_state.chunks = chunks
                        st.session_state.chunk_pages = chunk_pages
                        st.session_state.vectorizer = vectorizer
                        st.session_state.matrix = matrix
                        st.session_state.pdf_name = uploaded_file.name
                        st.session_state.page_count = page_count
                        st.session_state.messages = []
                        st.success("PDF loaded successfully.")
                    else:
                        st.error("Could not build the document search engine.")
                else:
                    st.error(
                        "No readable text was found. "
                        "This version works with text-based PDFs."
                    )

    st.divider()
    st.subheader("📊 Document Status")

    if st.session_state.pdf_name:
        st.write(f"**File:** {st.session_state.pdf_name}")
        st.write(f"**Pages:** {st.session_state.page_count}")
        st.write(f"**Search chunks:** {len(st.session_state.chunks)}")
        st.success("Document ready")
    else:
        st.info("No PDF uploaded.")

    st.divider()

    if st.button("🗑️ Clear Conversation", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    if st.button("🔄 Remove PDF", use_container_width=True):
        for key in [
            "pdf_name", "pdf_text", "chunks", "chunk_pages",
            "vectorizer", "matrix", "page_count"
        ]:
            st.session_state[key] = defaults[key]
        st.session_state.messages = []
        st.rerun()


# -------------------- Main interface --------------------
st.markdown(
    """
    <style>
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 7px 13px;
        border-radius: 20px;
        background: rgba(0, 180, 100, 0.12);
        font-weight: 700;
        font-size: 14px;
    }
    .status-dot {
        width: 9px;
        height: 9px;
        border-radius: 50%;
        background: #19c37d;
        display: inline-block;
    }
    .jarvis-subtitle {
        color: #777;
        margin-top: -10px;
        margin-bottom: 20px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="status-badge"><span class="status-dot"></span> JARVIS ONLINE</div>',
    unsafe_allow_html=True,
)

st.title("🤖 JARVIS")
st.markdown(
    '<div class="jarvis-subtitle">Intelligent conversational AI assistant with PDF document intelligence</div>',
    unsafe_allow_html=True,
)

c1, c2, c3, c4 = st.columns(4)

with c1:
    st.metric("NLP Engine", "ACTIVE")
with c2:
    st.metric("Messages", len(st.session_state.messages))
with c3:
    st.metric("Chunks", len(st.session_state.chunks))
with c4:
    st.metric(
        "PDF",
        "READY" if st.session_state.pdf_name else "NONE"
    )

st.divider()
st.subheader("💬 Chat with JARVIS")

if not st.session_state.messages:
    with st.chat_message("assistant"):
        st.markdown(
            """
            **Hello! I'm JARVIS. 🤖**

            Upload a PDF from the sidebar and ask questions about it.

            **Try:**
            - What is this document about?
            - Explain a topic from the PDF.
            - What are the main points?
            - Summarize this PDF.
            - What are its key concepts?
            """
        )

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

question = st.chat_input("Ask JARVIS something...")

if question:
    st.session_state.messages.append(
        {"role": "user", "content": question}
    )

    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("JARVIS is thinking..."):
            answer = generate_answer(question)
        st.markdown(answer)

    st.session_state.messages.append(
        {"role": "assistant", "content": answer}
    )
