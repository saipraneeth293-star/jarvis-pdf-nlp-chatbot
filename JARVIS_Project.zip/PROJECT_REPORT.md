# JARVIS — Conversational PDF NLP Chatbot
## Project Report

### 1. Abstract

JARVIS is a conversational chatbot developed using Python and Natural Language Processing techniques. The application provides a Streamlit-based interface through which users can upload a text-based PDF and ask questions about its contents. The system extracts text from the PDF, divides it into searchable chunks, converts the chunks into TF-IDF vectors, and uses cosine similarity to retrieve the most relevant sections for a user's question. JARVIS also provides extractive document summarization, short conversational context for follow-up questions, and source page references.

### 2. Problem Statement

Users often need to find specific information inside long PDF documents. Manually searching large documents is time-consuming. The objective of this project is to create a conversational interface that allows a user to ask natural-language questions and retrieve relevant information from an uploaded PDF.

### 3. Objectives

- Develop a Python-based conversational chatbot.
- Apply NLP techniques to user queries and document text.
- Extract readable text from PDF documents.
- Search document content using TF-IDF and cosine similarity.
- Provide concise answers based on relevant document sections.
- Generate an extractive summary of the uploaded document.
- Maintain short conversational context for follow-up questions.
- Display source page numbers for retrieved answers.
- Provide an accessible web interface using Streamlit.

### 4. Technologies Used

| Technology | Purpose |
|---|---|
| Python | Core programming language |
| Streamlit | Web application interface |
| PyPDF | PDF text extraction |
| scikit-learn | NLP retrieval and vectorization |
| TF-IDF | Text representation |
| Cosine similarity | Relevance ranking |
| Regular expressions | Text cleaning and sentence splitting |

### 5. System Architecture

User
→ Streamlit Interface
→ PDF Upload
→ PDF Text Extraction
→ Text Cleaning and Chunking
→ TF-IDF Vectorization
→ Similarity Search
→ Relevant Text Retrieval
→ JARVIS Response

For summarization:

PDF Text
→ Sentence Extraction
→ TF-IDF Sentence Scoring
→ Important Sentence Selection
→ Summary

### 6. Methodology

#### 6.1 PDF Processing

The uploaded PDF is read page by page using PyPDF. Extracted text is cleaned and retained with its page number.

#### 6.2 Text Chunking

Long page text is divided into overlapping chunks. Overlap helps preserve information that may occur near chunk boundaries.

#### 6.3 TF-IDF

Term Frequency-Inverse Document Frequency represents document chunks numerically according to the importance of words.

#### 6.4 Cosine Similarity

The user's question is transformed using the same TF-IDF vectorizer. Cosine similarity compares the query vector with document chunk vectors and ranks relevant chunks.

#### 6.5 Answer Generation

The highest-ranked chunks are converted into sentences. Candidate sentences are ranked using both query-word overlap and retrieval similarity. The strongest sentences are returned as the answer.

#### 6.6 Summarization

The application represents sentences with TF-IDF vectors and calculates sentence importance from aggregate term scores. The highest-scoring sentences are selected while preserving their original order.

#### 6.7 Conversation Context

For simple follow-up questions containing references such as "it", "its", "this", or "they", JARVIS combines the previous user question with the current question before searching the document.

### 7. User Interface

The Streamlit interface contains:

- JARVIS online status
- PDF upload control
- Document status panel
- Page and chunk counts
- Chat interface
- Conversation history
- Clear conversation button
- Remove PDF button
- Source page information

### 8. Testing

The following scenarios should be tested:

| Test | Expected Result |
|---|---|
| Upload valid text PDF | PDF loads successfully |
| Ask a document question | Relevant content is returned |
| Ask unrelated question | JARVIS reports that relevant information was not found |
| Request summary | Document summary is generated |
| Ask follow-up question | Previous topic is included as context |
| Upload a new PDF | Previous document data is replaced |
| Clear conversation | Chat history is removed |
| Remove PDF | Document state is reset |

### 9. Advantages

- Simple and lightweight architecture.
- No external API key is required.
- Easy to understand and demonstrate.
- Uses established NLP retrieval techniques.
- Provides source page information.
- Suitable for educational NLP/chatbot projects.
- Can run locally through Streamlit.

### 10. Limitations

- It is a retrieval-based chatbot rather than a large language model.
- Answers are limited to text extracted from the PDF.
- Scanned/image-only PDFs require OCR.
- Very complex questions may need more advanced semantic models.
- The conversational memory is intentionally lightweight.

### 11. Future Enhancements

Possible future improvements include:

- OCR for scanned PDFs.
- Sentence-transformer embeddings for semantic search.
- Retrieval-Augmented Generation (RAG).
- A locally hosted or API-based LLM.
- Multiple PDF support.
- Persistent chat history.
- Voice input and output.
- User authentication.
- Better citation highlighting.
- Cloud deployment.

### 12. Conclusion

JARVIS demonstrates how Python and NLP techniques can be combined to create a practical conversational chatbot. The project extracts information from PDF documents, represents text using TF-IDF, retrieves relevant information using cosine similarity, summarizes documents, maintains basic conversational context, and identifies source pages. The Streamlit interface makes the system easy to use and suitable for demonstration or academic submission.

### 13. Deployment

The project can be uploaded to GitHub with `app.py`, `requirements.txt`, `README.md`, and `.gitignore`. The Python virtual environment should not be uploaded. A Streamlit deployment service can then install dependencies from `requirements.txt` and run `app.py`.

